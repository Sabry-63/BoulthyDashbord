export default function StaticContentList() {
  return <div>static</div>;
}
